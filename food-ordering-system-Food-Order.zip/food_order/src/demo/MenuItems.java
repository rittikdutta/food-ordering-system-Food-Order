package demo;

import java.util.ArrayList;

public class MenuItems {
	private int price;
	String item_name;
	
	MenuItems(int price,String item_name)
	{
		this.price = price;
		this.item_name = item_name;
		
	}
	
	public void Add_items(int price,String name){
		
		
	}

}
